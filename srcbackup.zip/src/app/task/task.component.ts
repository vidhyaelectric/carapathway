import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent  {
  filtertask="";
  taskpercent=2;
  trackpercent=92;
  taskcolor='#d54d79';
  trackcolor='#3cb371';
  tasktitle="TODAY'S TASKS";
  tracktitle= this.trackpercent +"% ON TRACK";
  logoimgsrc= "./assets/logo.png";
  constructor() { }
     tasks:any[] =
    [
      {
            "id": 1,
            "name": "Outcome Needed",
            "details": "Colon Cancer,Initial Treatment",
            "date": '05/17/2018',
            "patient": "John Doe",
            "patientid":"09827361",
            "highlightflag":true,
            "image": "./assets/highlighter.png"
      },
      {
        "id": 2,
        "name": "AUthorization Expiring",
        "details": "Colon Cancer,Radiation",
        "date": '05/30/2018',
        "patient": "Bob Smith",
        "patientid":"09827362",
        "highlightflag":true,
        "image": "./assets/highlighter.png"
      },
      {
        "id": 3,
        "name": "Complete pathway",
        "details": "Lung Cancer",
        "date": '5 Weeks',
        "patient": "Jeff Charles",
        "patientid":"09827362",
        "highlightflag":false,
        "image": "./assets/highlighter.png"
      },
      {
        "id": 4,
        "name": "Outcome Needed",
        "details": "Breast Cancer,Biopsy",
        "date": '06/30/2018',
        "patient": "MAry Sue",
        "patientid":"09827362",
        "highlightflag":false,
        "image": "./assets/highlighter.png"
      }
    ]
   /* taskdial:any[]=
    [
      {
        "taskpercent":2,
        "trackpercent":92,
        "taskcolor":'#FF0000',
        "trackcolor":'#3cb371'
      }
    ]
*/
}
