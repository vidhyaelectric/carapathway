import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import {
  AuthModule,
  OidcSecurityService,
  OpenIDImplicitFlowConfiguration,
  OidcConfigService,
  AuthWellKnownEndpoints
} from 'angular-auth-oidc-client';
import { RedirectComponent } from './redirect/redirect.component';
import { Routes, RouterModule } from '@angular/router';
import { environment } from '../environments/environment';
import { TaskComponent } from './task/task.component';
import { NavbarComponent } from './navbar/navbar.component';
import { DialComponent } from './dial/dial.component';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { GaugeComponent } from './gauge/gauge.component';
//import { GaugeModule } from 'ng-gauge';
//import { GaugeSegment, GaugeLabel } from 'ng-gauge';
/*export function loadConfig(oidcConfigService: OidcConfigService) {
  console.log('APP_INITIALIZER STARTING');
//  return () => oidcConfigService.load_using_custom_stsServer('https://login.microsoftonline.com/BetaCPCB2c.onmicrosoft.com/v2.0/.well-known/openid-configuration?p=B2C_1_Beta_SingUpPolicy');
}*/

const appRoutes: Routes = [
  { path: '', redirectTo: 'task', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'redirect.html', component: RedirectComponent },
  { path: 'task', component: TaskComponent},
  { path: 'navbar', component: NavbarComponent},
];


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RedirectComponent,
    TaskComponent,
    NavbarComponent,
    DialComponent,
    GaugeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AuthModule.forRoot(),
    RouterModule.forRoot(appRoutes),
    NgCircleProgressModule.forRoot({
      // set defaults here
  /*    radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: "#78C000",
      innerStrokeColor: "#C7E596",
      animationDuration: 300   */
      "radius": 60,
      "space": -10,
      "outerStrokeWidth": 10,
      "outerStrokeColor": "#4882c2",
      "innerStrokeColor": "#e7e8ea",
      "innerStrokeWidth": 10,
      "animateTitle": false,
      "animationDuration": 1000,
      "showUnits": false,
      "showBackground": false,
      "clockwise": false ,
      "subtitle":"Due < 1 WEEK"     
    })
  ],
  providers: [
   /* OidcConfigService,
    {
        provide: APP_INITIALIZER,
        useFactory: loadConfig,
        deps: [OidcConfigService],
        multi: true
    }*/
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}

