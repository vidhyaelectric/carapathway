import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent /*implements OnInit, OnDestroy */{

  /*isAuthorized: boolean;
  isAuthorizedSubscription: Subscription;
  apiResult: string;
  userDataSubscription:Subscription;
  userData: boolean;
  constructor(private oidcSecurityService: OidcSecurityService, private http: HttpClient) {
    this.isAuthorized = false;
  }

  ngOnInit() {
    this.isAuthorizedSubscription = this.oidcSecurityService.getIsAuthorized()
      .subscribe(isAuthorized => this.isAuthorized = isAuthorized);
      console.log('oninit');
      console.log(this.isAuthorized);
      console.log(this.oidcSecurityService.getIsAuthorized());
      this.userDataSubscription = this.oidcSecurityService.getUserData().subscribe(
        (userData: any) => {
             this.userData = userData
        });
        console.log(this.userData);

  }

  ngOnDestroy() {
    this.isAuthorizedSubscription.unsubscribe();
  }

  signUp() {
    console.log('signup');
   // console.log(this.oidcSecurityService.authorize());    
    this.oidcSecurityService.authorize();
  }

  signOut() {
    this.oidcSecurityService.logoff();
  }

  callApi() {
    const token = this.oidcSecurityService.getToken();
    console.log('token');
    console.log(this.oidcSecurityService.getToken());
    const apiURL = 'https://fabrikamb2chello.azurewebsites.net/hello';
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

    this.http.get(apiURL, { headers: headers }).subscribe(
        response => this.apiResult = JSON.stringify(response),
        error => console.log(error)
        );
        console.log('API result');
        console.log(JSON.stringify(this.apiResult));
   
  }
*/
}
